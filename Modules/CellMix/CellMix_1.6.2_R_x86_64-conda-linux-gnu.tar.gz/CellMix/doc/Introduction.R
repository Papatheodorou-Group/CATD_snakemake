## ----pkgmaker_preamble, echo=FALSE, results='asis'----------------------------
pkgmaker::latex_preamble('CellMix')

## ----bibliofile, echo=FALSE, results='asis'-----------------------------------
pkgmaker::latex_bibliography('CellMix')


## ----cellmix_load, echo=FALSE, include=FALSE----------------------------------
library(xtable)
library(CellMix)
summary <- function(x){
	if( is(x, 'MarkerList') ){
		res  <- getMethod('summary', 'MarkerList')(x)
		print(res)
		invisible(res)
	} else base::summary(x)
}


## ----GEOquery, eval=FALSE-----------------------------------------------------
## # install biocLite
## install.packages('BiocInstaller')
## # or alternatively do:
## # source('http://www.bioconductor.org/biocLite.R')
## 
## # install GEOquery (NB: might ask you to update some of your packages)
## library(BiocInstaller)
## biocLite('GEOquery')


## ----GSE19830_pdata_fake, eval=FALSE------------------------------------------
## # Dataset: GSE19830 [Shen-Orr et al. (2010)]
## GSE19830 <- getGEO('GSE19830')[[1]]
## levels(GSE19830$characteristics_ch1)

## ----GSE19830_pdata_load, echo=FALSE, cache=TRUE------------------------------
local({
	GSE19830 <- eset(gedData('GSE19830'))
	levels(GSE19830$characteristics_ch1)
})


## ----GSE5350_pdata_fake, eval=FALSE-------------------------------------------
## # Dataset: GSE5350 (MACQ project) [HUMAN]
## GSE5350 <- getGEO('GSE5350')[[1]]
## # extract Affy Human dataset (i.e. GEO platform GPL570)
## i <- grep("GPL570", attr(GSE5350, "names"))
## GSE5350 <- GSE5350[[i]]
## # extract only mixture experiments
## GSE5350[, grep("^MAQC", GSE5350$source_name_ch1)]
## levels(droplevels(GSE5350$source_name_ch1))

## ----GSE5350_pdata_load, echo=FALSE, cache=TRUE-------------------------------
local({
	e <- eset(gedData('GSE5350'))
	levels(head(e$source_name_ch1))
})


## ----loadAbbas, echo=FALSE----------------------------------------------------
data(Abbas)


## ----ExpressionMix_sample, cache=TRUE-----------------------------------------
## load data
emix <- ExpressionMix('GSE11058')

## get relevant sample annotation
# cell type
emix$Type
# cell type of origin
emix$CType

## get the reference mixing proportions
coef(emix)[, c(1,4,7,13:15)]
## get the reference cell-type specific signatures
head(basis(emix), 3)


## ----ged_blood, eval=-8, echo=TRUE, cache=TRUE, fig.keep='none'---------------
# load data
e <- ExpressionMix('GSE20300')
# compute proportions (show processing) 
res <- gedBlood(e, verbose=TRUE)
# aggregate into CBC
cbc <- asCBC(res)
# plot against actual CBC
profplot(e, cbc)


## ----ged_blood_plot, echo=FALSE, out.width="0.5\\textwidth"-------------------
mar <- par('mar')
mar[3] <- 1
par(mar=mar)
profplot(e, cbc, ylim=c(0,1), xlim=c(0,1)
, main='', xlab="Actual CBC proportions", ylab='Computed proportions')


## ----GEDmarker, echo=FALSE----------------------------------------------------
n_GEDmarkers <- length(cellMarkers())


## ----load_markers-------------------------------------------------------------
m <- MarkerList('Palmer')
summary(m)


## ----mAbbas_sparseness, echo=FALSE, fig.width=10------------------------------
local({
# load the Abbas dataset
data(Abbas, envir=environment())
# load the marker list derived from the Abbas dataset 
m <- cellMarkers('Abbas', sparsity=0, id='SYMBOL')

# select the 3 least/most sparse markers
s <- sort(unlist2(m), decreasing=TRUE)
s <- c(head(s, 3), tail(s, 3))
pid <- names(s)

# make legend
f <- fData(Abbas)
leg <- paste(pid, ' - ', f[pid,'SYMBOL'], ' (', round(s,2),')', sep='')

# plot with divergent colors
library(colorspace)
cols <- rev(diverge_hcl(length(pid)+1)[-length(pid)/2-1])
par(mar=c(7,6,1,1))
barplot(exprs(Abbas[pid,]), las=2, beside=TRUE, col=cols, cex.names=0.9)
title(ylab="Marker expression values", line=4)
title(xlab="Immune cell types", line=5)
legend('topleft', legend=leg, fill=cols, cex=0.9, inset=0.1, ncol=2)
})


## ----GEDdata_table, echo=FALSE, results='asis'--------------------------------
print(xtable(gedDataInfo(FALSE), citet=TRUE), floating=FALSE, only.contents=TRUE
		, sanitize.text.function=xsanitize("\\{}"))


## ----GEDmarkers_table, echo=FALSE, results='asis'-----------------------------
print(xtable(cellMarkersInfo(FALSE), citet=TRUE), floating=FALSE, only.contents=TRUE
	, sanitize.text.function=xsanitize("\\{}"))


## ----markers_usecase, cache=TRUE----------------------------------------------
## PRELIMINARY: load data from the internal registries
# load HaemAtlas markers 
m <- MarkerList('HaemAtlas')
summary(m)
# load the data using its key
# NB: require Internet access on first usage)
e <- ExpressionMix('GSE11058')
# probes are not from the same platform
annotation(e)
##

# convert Illumina to the IDs used in the expression data (HGU133plus2)
# -> this looks for a single match per probe, dropping non-primary affy probes
m_affy <- convertIDs(m, e)
summary(m_affy)


## ----Wmarkers_contents_plot, fig.width=11, echo=8:9---------------------------
mar <- par('mar')
mar[3] <- 1
par(cex.axis=0.7, las=2, mfrow=c(1,2), mar=mar)
i <- grep("^T-", names(m), invert=TRUE)
names(m)[i] <- sub("-.*$", "", names(m)[i])
names(m_affy) <- names(m)
#
bp <- barplot(m, main=annotation(m))
barplot(m_affy, ylim=bp$ylim, main=annotation(m_affy))


## ----Wmarkers_barplot, include=FALSE------------------------------------------
# extract the pure samples only: Jurkat, Raji, IM-9, THP-1
pure <- pureSamples(e)
# reorder the markers by max-min score
mo <- reorder(m_affy, pure, by=pure$Type)
# plot mean expression of top 50 markers for each cell line
avg <- rowMeansBy(pure, paste(pure$CType, pure$Type, sep=' - '))
barplot(mo[,1:50], avg)

## ----Wmarkers_barplot_plot, fig.width=10, echo=FALSE--------------------------
mar <- par('mar')
mar[3] <- 1
par(mar=mar)
barplot(mo[,1:50], avg, legend='topright')
# save for appendix with explicit names
Wmarkers <- mo; Wmarker_AVG <- avg


## ----Wmarkers_Abbas_barplot, fig.width=10, echo=c(1:2, 4:5)-------------------
# convert Illumnina marker ids to match Abbas feature id type
ma <- convertIDs(m, Abbas, method='all')
par(mar=c(7,6,1,1))
# plot markers expression values in Abbas dataset
barplot(ma, Abbas, las=2, ylab='')
title(ylab="Marker expression values", line=4)
title(xlab="Immune cell types", line=5)


## ----markermaps, eval=FALSE---------------------------------------------------
## basismarkermap(mo[,1:50], avg, Rowv=NA)
## basismarkermap(ma, Abbas, Rowv=NA)


## ----markermap_cellline, echo=FALSE, out.width="0.45\\textwidth"--------------
basismarkermap(mo[,1:50], avg, Rowv=NA)


## ----markermap_abbas, echo=FALSE, out.width="0.45\\textwidth"-----------------
basismarkermap(ma, Abbas, Rowv=NA)


## ----GEDalgorithm_table, echo=FALSE, results='asis'---------------------------
print(xtable(gedAlgorithmInfo(FALSE, all=FALSE), citet=TRUE), floating=FALSE, only.contents=TRUE
		, sanitize.text.function=xsanitize("\\{}$"))


## ----ged_interface, eval=FALSE------------------------------------------------
## # expression data only: deconf
## ged(X, 3)
## # with markers only: qprog
## ged(X, marks)
## # with markers only, iterative: ssBrunet
## ged(X, marks, maxIter=1000)
## # with known signatures: qprog
## ged(X, sig)
## # with known proportions: csSAM
## ged(X, prop)
## # with uncertain proportions, iterative: DSection
## ged(X, prop, maxIter=500)
## 
## # force a given algorithm, with extra parameter: ssLee
## ged(X, 2, method='ssLee', markers=marks, ratio=3)


## ----load_TDDB, echo=FALSE----------------------------------------------------
data(TissueDistributionDB_HS)
data(TissueDistributionDB_RN)


## ----sessionInfo, echo=FALSE, results='asis'----------------------------------
utils::toLatex(sessionInfo())


## ----markers_convert_verbose--------------------------------------------------
# load data from registry
m <- MarkerList('HaemAtlas')
e <- ExpressionMix('GSE11058')

# convert Affy IDs from HGU133A/B to HGUplus2 (showing details of the mapping process)
m_affy_all <- convertIDs(m,e, verbose=4)


## ----ged_blood_norm_def, echo=FALSE-------------------------------------------
# load data
e <- ExpressionMix('GSE20300')
pplot <- function(...)
	profplot(..., ylim=c(0,1), xlim=c(0,1)
			, xlab="Actual CBC proportions", ylab='Computed proportions')

## ----ged_blood_qlog-----------------------------------------------------------
# Quantile normalized - Log-scale
res <- gedBlood(e)

## ----ged_blood_qlog_plot, echo=FALSE------------------------------------------
# plot against actual CBC
pplot(e, asCBC(res), main="Quantile normalised - Log scale")


## ----ged_blood_qlin-----------------------------------------------------------
# Quantile normalized - Linear scale 
res <- gedBlood(expb(e, 2))

## ----ged_blood_qlin_plot, echo=FALSE------------------------------------------
# plot against actual CBC
pplot(e, asCBC(res), main="Quantile normalised - Linear scale")


## ----ged_blood_l--------------------------------------------------------------
# Log-transformed only
res <- gedBlood(e, normalize=FALSE)

## ----ged_blood_l_plot, echo=FALSE---------------------------------------------
# plot against actual CBC
pplot(e, asCBC(res), main="No normalisation - Log scale")


## ----ged_blood_diff-----------------------------------------------------------
# Linear scale
res <- gedBlood(expb(e, 2), normalize=FALSE)

## ----ged_blood_diff_plot, echo=FALSE------------------------------------------
# plot against actual CBC
pplot(e, asCBC(res), main="No normalisation - Linear scale")


## ----Wmarkers_barplot_ALL, echo=FALSE, fig.width=10---------------------------
barplot(Wmarkers, Wmarker_AVG, legend='topright')

