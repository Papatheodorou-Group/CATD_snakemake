## ----pkgmaker_preamble, echo=FALSE, results='asis'----------------------------
pkgmaker::latex_preamble('CellMix')

## ----bibliofile, echo=FALSE, results='asis'-----------------------------------
pkgmaker::latex_bibliography('CellMix')


## ----hacks, echo=FALSE--------------------------------------------------------
summary <- function(x){
	if( is(x, 'MarkerList') ){
		res  <- getMethod('summary', 'MarkerList')(x)
		print(res)
		invisible(res)
	} else base::summary(x)
}

# knitr options
opts_knit$set(progress = TRUE, verbose = TRUE, stop_on_error=2)
opts_chunk$set(size='small', out.width="0.6\\textwidth")


## ----myCRAN, eval=FALSE-------------------------------------------------------
## 
## # install biocLite if not already there
## if( !require(BiocInstaller) ){
## 	# enable Bioconductor repositories
## 	# -> add Bioc-software
## 	setRepositories()
## 	
## 	install.packages('BiocInstaller')
## 	library(BiocInstaller)
## }
## # or alternatively do:
## # source('http://www.bioconductor.org/biocLite.R')
## 
## # install (NB: might ask you to update some of your packages)
## biocLite('CellMix', siteRepos = 'http://web.cbio.uct.ac.za/~renaud/CRAN')
## # load
## library(CellMix)


## ----GEOquery, eval=FALSE-----------------------------------------------------
## biocLite('GEOquery')


## ----load, echo=FALSE, include=FALSE------------------------------------------
library(CellMix)
library(AnnotationDbi)
library(limSolve)
library(matrixStats)


## ----blood--------------------------------------------------------------------
# load data (normally requires an internet connection to GEO)
acr <- ExpressionMix('GSE20300', verbose=2)

# the result is a combination of an ExpressionSet and an NMF model object
acr


## ----gedBlood-----------------------------------------------------------------
# estimate proportions using signatures from Abbas et al. (2009) 
res <- gedBlood(acr, verbose=TRUE)


## ----res_gedBlood-------------------------------------------------------------
# result object
res

# proportions are stored in the coefficient matrix
dim(coef(res))
coef(res)[1:3, 1:4]

# cell type names
basisnames(res)

# basis signatures (with converted IDs)
basis(res)[1:5, 1:3]


## ----plot_gedBlood, fig.show='hold', out.width="0.5\\textwidth"---------------
# aggregate into CBC
cbc <- asCBC(res)
dim(cbc)
basisnames(cbc)

# plot against actual CBC
profplot(acr, cbc)
# plot cell proportion differences between groups
boxplotBy(res, acr$Status, main="Cell proportions vs Transplant status")


## ----known_sig_data-----------------------------------------------------------
# load data (requires internet connection to GEO)
gse <- ExpressionMix('GSE19830', verbose=TRUE)
gse

# extract data for mixed samples only
mix <- mixedSamples(gse)

# extract stored known signatures (= average pure profiles)
sig <- basis(mix)


## ----known_sig----------------------------------------------------------------
# estimate proportions from pure signatures (default: no normalization)
res <- ged(mix, sig, verbose=TRUE, log=FALSE)

# plot against known proportions
profplot(mix, res)


## ----extractmarkers_basis-----------------------------------------------------
# extract data for pure samples only
pure <- pureSamples(gse)

# compute p-values for all probes
ml <- extractMarkers(pure, pure$Type, method='Abbas')
# all probes get attributed a cell-type and a p-value
summary(ml)


## ----ged_basis_pvalues, fig.show='hold', out.width="0.5\\textwidth"-----------
# Filtering 1:
# show p-values histogram 
hist(ml, breaks=20)
summary(ml <= 10^-8)

# refit proportions using only the subset of markers with p-value <= 10^-8
res2 <- ged(mix, basis(gse), subset=ml <= 10^-8, log=FALSE)
# plot against known proportions
profplot(mix, res2)


## ----condition_number, fig.show='hold', out.width="0.5\\textwidth"------------
# Filtering 2:
# select limited number of markers based on the 
# signature matrix's condition number as proposed by Abbas et al. (2009) 
sel <- screeplot(ml, basis(gse), range=1:500)
summary(sel)

# refit proportions using the optimised set of markers
res3 <- ged(mix, basis(gse), subset=sel, log=FALSE)
# plot against known proportions
profplot(mix, res3)


## ----mean_markers, out.width="0.5\\textwidth", fig.show='hold'----------------
# check if data is in log scale
is_logscale(mix)

# compute mean expression profiles within each cell type
p <- ged(expb(mix, 2), sel, 'meanProfile')
# plot against known proportions (p is by default not scaled)
profplot(mix, p, scale=TRUE, main='meanProfile - Linear scale')

# compute mean expression profiles within each cell type
lp <- ged(mix, sel, 'meanProfile')
# plot against known proportions (p is by default not scaled)
profplot(mix, lp, scale=TRUE, main='meanProfile - Log scale')

# compute proportions using DSA methods [Zhong et al. (2013)]
pdsa <- ged(mix[sel], sel, 'DSA', verbose=TRUE)
profplot(mix, pdsa, main='DSA - Linear scale')
pdsa <- ged(mix[sel], sel, 'DSA', log=FALSE)
profplot(mix, pdsa, main='DSA - Log scale')


## ----csSAM, cache=TRUE--------------------------------------------------------
# take the 5000 most variable genes
s <- esApply(acr, 1L, sd, na.rm=TRUE)
i <- order(s, decreasing=TRUE)[1:5000]
# fit csSAM for the groups defined in covariate 'Status' 
rescs <- ged(acr[i,], coef(acr), method='csSAM', data=acr$Status, nperms=200, verbose=TRUE)


## ----csplot, fig.height=8, fig.width=15, out.width='\\textwidth'--------------
csplot(rescs)


## ----DSection, eval = FALSE, cache=TRUE, fig.show='hold', out.width="0.5\\textwidth"----
## # generate random data: 3 cell types, 20 samples, 100 genes
## # and 5 markers per cell type
## x <- rmix(3, 100, 20, markers=5)
## x
## # show true basis signatures (the markers clearly appear)
## basismap(x, Rowv=NA)
## 
## # add noise to the proportions
## p0 <- abs(coef(x) + rmatrix(coef(x), dist=rnorm, sd=0.2))
## # rescale into proportion (columns sum up to one)
## p0 <- scoef(p0)
## # see how noisy they got
## profplot(x, p0)
## 
## # fit DSection MCMC model
## ds <- ged(x, p0, 'DSection', maxIter=20, verbose=TRUE)
## # check reduction of noise on proportions
## profplot(x, ds)


## ----semi, cache=TRUE, fig.show='hold', out.width="0.5\\textwidth"------------
# generate random data with 5 markers per cell type
x <- rmix(3, 200, 20, markers=5)
m <- getMarkers(x)

# deconvolve using KL-divergence metric
kl <- ged(x, m, 'ssKL', log=FALSE, rng=1234, nrun=10)

# plot against known proportions
profplot(x, kl)
# check consistency of most expressing cell types in known basis signatures
basismarkermap(basis(x), kl)
# correlation with known signatures
basiscor(x, kl)


## ----deconf, cache=TRUE, fig.show='hold', out.width="0.5\\textwidth"----------
# deconvolve using KL divergence metric
dec <- ged(x, m, 'deconf', rng=1234, nrun=10)

# plot against known proportions
profplot(x, dec)
# check consistency of most expressing cell types in known signatures 
basismarkermap(basis(x), dec)
# correlation with known signatures
basiscor(x, dec)


## ----sessionInfo, echo=FALSE, results='asis'----------------------------------
utils::toLatex(sessionInfo())

