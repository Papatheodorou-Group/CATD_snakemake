## ----pkgmaker_preamble, echo=FALSE, results='asis'----------------------------
pkgmaker::latex_preamble()


## ----options, echo=FALSE, include=FALSE---------------------------------------
library(knitr)
opts_chunk$set(dev=c('cairo_ps', 'pdf'), fig.path='./fig-', size='scriptsize', fig.align='center', out.width="0.35\\textwidth")
library(CellMix)


## ----gedblood_code, eval=FALSE------------------------------------------------
## # load benchmark data
## acr <- ExpressionMix('GSE20300')
## # compute proportions
## res <- gedBlood(acr)
## # plot against actual CBC
## profplot(acr, asCBC(res))


## ----markers_code, eval=FALSE-------------------------------------------------
## # load/extract expression data
## pure <- pureSamples(ExpressionMix('GSE11058'))
## # load/convert HaemAtlas markers
## m <- convertIDs(cellMarkers('HaemAtlas'), pure)
## # reorder/plot markers based on maximum average expression
## avg <- rowMeansBy(pure, pure$LType)
## m <- reorder(m, avg, fun=max)
## basismarkermap(m[,1:50], avg)


## ----gedblood, include=FALSE, fig.keep='last'---------------------------------
# load benchmark data
acr <- ExpressionMix('GSE20300')
# compute proportions 
res <- gedBlood(acr)
# plot against actual CBC
profplot(acr, asCBC(res))
profplot(acr, asCBC(res), xlab='Measured CBC proportions', ylab='Estimated proportions')

## ----markers, include=FALSE, fig.keep='last'----------------------------------
# load/extract expression data
pure <- pureSamples(ExpressionMix('GSE11058'))
# load/convert HaemAtlas markers
m <- convertIDs(cellMarkers('HaemAtlas'), pure)
# reorder/plot markers based on maximum average expression
avg <- rowMeansBy(pure, pure$LType)
m <- reorder(m, avg, fun=max)
basismarkermap(m[,1:50], avg)
basismarkermap(m[,1:50], avg, annCol=list(Origin=c("B", "B", "Monocyte", "T")), labCol="/^[^-]+-(.*)$/")

