## ----pkgmaker_preamble, echo=FALSE, results='asis'----------------------------
pkgmaker::latex_preamble('CellMix')


## ----hacks, echo=FALSE--------------------------------------------------------
summary <- function(x){
	if( is(x, 'MarkerList') ){
		res  <- getMethod('summary', 'MarkerList')(x)
		print(res)
		invisible(res)
	} else base::summary(x)
}

opts_chunk$set(out.width="0.6\\textwidth")


## ----load_package, include=FALSE----------------------------------------------
library(CellMix)


## ----list_markers-------------------------------------------------------------
# list access keys
cellMarkers()

## ----longlist_markers, eval=FALSE---------------------------------------------
## # show full property table
## cellMarkersInfo()


## ----load_marker--------------------------------------------------------------
# load HaemAtlas markers
m <- cellMarkers('HaemAtlas')
# or
m <- MarkerList('HaemAtlas')


## ----summary_markers----------------------------------------------------------
# load 
m <- MarkerList('HaemAtlas')
# show summary
summary(m)
# plot number of markers for each cell type
barplot(m)


## ----subset_markers-----------------------------------------------------------
# subset the cell types
summary(m[1:3])

# Take only first n markers of each cell type
summary(m[,1:3])

# subset markers that are present in some dataset
# => this converts/maps IDs if necessary
x <- ExpressionMix('GSE11058')
subset(m, x, verbose=TRUE)


## ----convertML----------------------------------------------------------------

# load marker list that contains scores
ml <- cellMarkers('TIGER')

# plain list dropping values
l <- geneIds(ml)
str(head(l))

# plain list keeping values
l <- geneValues(ml)
str(head(l))


## ----MarkerList_factory-------------------------------------------------------
# basic data
m <- setNames(letters[1:10], rep(c('CT1', 'CT2'), 5))
m

# from character vector with names corresponding to cell types
ml <- MarkerList(m)
geneIds(ml)

# from a list
m_list <- split(m, names(m))
ml <- MarkerList(m_list)
geneIds(ml)

# from a delimited text file: marker names, cell type
mf <- cbind(m, names(m))
mf
write.table(mf, file = 'markers.txt', row.names = FALSE)
ml <- MarkerList(file = 'markers.txt', header = TRUE)
geneIds(ml)
file.remove('markers.txt')


## ----list_data----------------------------------------------------------------
# list access keys
gedData()

## ----longlist_data, eval=FALSE------------------------------------------------
## # show full property table
## gedDataInfo()


## ----load_data----------------------------------------------------------------
# load GSE29832 from Gong et al. (2011)
mix <- ExpressionMix('GSE29832')
mix


## ----emix_dims----------------------------------------------------------------
# dimensions of an ExpressionMix object
dim(mix)


## ----emix_eset----------------------------------------------------------------
class(eset(mix))
class(exprs(mix))
dim(exprs(mix))


## ----emix_coef----------------------------------------------------------------
dim(coef(mix))


## ----emix_basis---------------------------------------------------------------
dim(basis(mix))


## ----list_methods-------------------------------------------------------------
# list access keys
gedAlgorithm()

## ----longlist_methods, eval=FALSE---------------------------------------------
## # show full property table
## gedAlgorithmInfo()

