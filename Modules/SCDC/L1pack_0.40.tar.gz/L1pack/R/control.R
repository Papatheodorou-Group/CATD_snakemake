## ID: control.R, last updated 2020-10-09, F.Osorio and T.Wolodzko

l1pack.control <- function(maxIter = 2000, tolerance = 1e-9)
{
  list(maxIter = maxIter, tolerance = tolerance)
}
